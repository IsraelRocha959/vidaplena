"""
Cria dados de demonstração (SOMENTE em desenvolvimento).

Uso:  python manage.py seed_demo
As senhas são geradas aleatoriamente e exibidas uma única vez no terminal.
"""
import secrets
from datetime import time

from django.conf import settings
from django.contrib.auth.models import User
from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from agenda.models import HorarioAtendimento, Paciente, Papel, Perfil, Profissional, Unidade


class Command(BaseCommand):
    help = "Cria unidades, usuários de cada perfil, grade de horários e um paciente de exemplo."

    def handle(self, *args, **options):
        if not settings.DEBUG:
            raise CommandError("seed_demo só roda com DJANGO_DEBUG=1 (nunca em produção).")

        senha = secrets.token_urlsafe(12)
        centro, _ = Unidade.objects.get_or_create(nome="Centro", defaults={"endereco": "Rua Exemplo, 100"})
        norte, _ = Unidade.objects.get_or_create(nome="Norte", defaults={"endereco": "Av. Exemplo, 200"})

        def usuario(login, papel, unidade=None):
            u, _ = User.objects.get_or_create(username=login)
            u.set_password(senha)  # ambiente de DEV: redefine a senha a cada execução
            u.save()
            Perfil.objects.update_or_create(user=u, defaults={"papel": papel, "unidade": unidade})
            return u

        recepcao = usuario("recepcao.centro", Papel.RECEPCAO, centro)
        u_prof = usuario("dra.souza", Papel.PROFISSIONAL)
        u_pac = usuario("paciente.demo", Papel.PACIENTE)

        prof, _ = Profissional.objects.get_or_create(
            user=u_prof, defaults={"nome": "Dra. Ana Souza", "especialidade": "Clínica Geral", "registro_profissional": "CRM/SP 000000"}
        )
        prof.unidades.add(centro)
        for dia in range(0, 5):  # segunda a sexta, 08:00-12:00, consultas de 30 min
            HorarioAtendimento.objects.get_or_create(
                profissional=prof, unidade=centro, dia_semana=dia,
                defaults={"hora_inicio": time(8, 0), "hora_fim": time(12, 0), "duracao_min": 30},
            )

        Paciente.objects.get_or_create(
            cpf="52998224725",  # CPF de teste válido (não é de pessoa real)
            defaults={
                "nome": "Paciente Demonstração", "data_nascimento": "1990-05-20", "telefone": "(15) 90000-0000",
                "user": u_pac, "consentimento_lgpd": True, "consentimento_em": timezone.now(),
            },
        )

        self.stdout.write(self.style.SUCCESS("Dados de demonstração criados."))
        self.stdout.write(f"Senha de TODOS os usuários abaixo (anote, não será exibida de novo): {senha}")
        for login, papel in [("recepcao.centro", "Recepção (Centro)"), ("dra.souza", "Profissional"), ("paciente.demo", "Paciente")]:
            self.stdout.write(f"  - {login}  [{papel}]")
        self.stdout.write("Administrador: crie com  python manage.py createsuperuser")
