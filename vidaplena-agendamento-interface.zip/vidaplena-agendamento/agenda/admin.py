"""
Painel administrativo (/gestao-admin/): cadastro de unidades, profissionais, grade de
horários e perfis de acesso. Restrito a superusuários (is_staff + permissões do Django).

Agendamentos e auditoria são SOMENTE LEITURA aqui: alterações de agendamento devem passar
por services.py para respeitar as regras de conflito e gerar auditoria.
"""
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User

from .models import (
    Agendamento, HorarioAtendimento, Paciente, Perfil, Profissional, RegistroAuditoria, Unidade,
)


class PerfilInline(admin.StackedInline):
    model = Perfil
    can_delete = False
    extra = 1
    max_num = 1


class UserAdmin(BaseUserAdmin):
    inlines = [PerfilInline]  # define o papel direto na tela do usuário


admin.site.unregister(User)
admin.site.register(User, UserAdmin)


@admin.register(Unidade)
class UnidadeAdmin(admin.ModelAdmin):
    list_display = ("nome", "endereco", "ativa")
    list_filter = ("ativa",)


class HorarioInline(admin.TabularInline):
    model = HorarioAtendimento
    extra = 1


@admin.register(Profissional)
class ProfissionalAdmin(admin.ModelAdmin):
    list_display = ("nome", "especialidade", "registro_profissional", "ativo")
    list_filter = ("ativo", "unidades")
    search_fields = ("nome", "especialidade")
    filter_horizontal = ("unidades",)
    inlines = [HorarioInline]


@admin.register(Paciente)
class PacienteAdmin(admin.ModelAdmin):
    list_display = ("nome", "cpf_mascarado", "telefone", "ativo")  # CPF mascarado na listagem
    search_fields = ("nome", "cpf")
    list_filter = ("ativo",)
    exclude = ("consentimento_em",)


@admin.register(Agendamento)
class AgendamentoAdmin(admin.ModelAdmin):
    list_display = ("inicio", "paciente", "profissional", "unidade", "status")
    list_filter = ("status", "unidade", "profissional")
    date_hierarchy = "inicio"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(RegistroAuditoria)
class RegistroAuditoriaAdmin(admin.ModelAdmin):
    list_display = ("criado_em", "acao", "entidade", "entidade_id", "usuario_texto", "ip")
    list_filter = ("acao",)
    search_fields = ("usuario_texto", "entidade_id")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
