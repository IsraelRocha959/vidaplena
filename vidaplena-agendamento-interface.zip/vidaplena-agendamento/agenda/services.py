"""
CAMADA DE REGRAS DE NEGÓCIO.

Toda criação/alteração de agendamento passa por aqui (views e admin não gravam direto).
Assim a regra "não pode haver conflito de horário" existe em UM só lugar e é testável.

Defesa em DUAS camadas contra conflitos:
  1) Esta camada: valida dentro de uma TRANSAÇÃO e trava a linha do profissional
     (SELECT ... FOR UPDATE) para serializar tentativas simultâneas.
  2) O banco (PostgreSQL): restrição de exclusão (db_constraints.py). Se mesmo assim
     duas gravações colidirem, o banco recusa e convertemos o erro em ConflitoHorarioError.
"""
import logging
from datetime import datetime, time, timedelta

from django.db import IntegrityError, transaction
from django.utils import timezone

from .models import (
    STATUS_ATIVOS, Agendamento, HorarioAtendimento, Profissional, RegistroAuditoria, Status,
)

logger = logging.getLogger(__name__)


class RegraNegocioError(Exception):
    """Violação de regra de negócio; a mensagem é segura para mostrar ao usuário."""


class ConflitoHorarioError(RegraNegocioError):
    """Horário já ocupado (profissional ou paciente)."""


# Transições permitidas ao ATUALIZAR STATUS (cancelamento tem função própria).
TRANSICOES = {
    Status.AGENDADO.value: {Status.CONFIRMADO.value, Status.CONCLUIDO.value, Status.FALTOU.value},
    Status.CONFIRMADO.value: {Status.CONCLUIDO.value, Status.FALTOU.value},
}


# ---------------------------------------------------------------------------
# Auditoria
# ---------------------------------------------------------------------------
def registrar_auditoria(*, usuario=None, usuario_texto=None, acao, entidade, entidade_id="", detalhe="", ip=None):
    """Grava uma linha na trilha de auditoria. Nunca deve derrubar a operação principal."""
    try:
        autenticado = usuario is not None and getattr(usuario, "is_authenticated", False)
        RegistroAuditoria.objects.create(
            usuario=usuario if autenticado else None,
            usuario_texto=(usuario.get_username() if autenticado else (usuario_texto or "")),
            acao=acao,
            entidade=entidade,
            entidade_id=str(entidade_id),
            detalhe=detalhe,
            ip=ip,
        )
    except Exception:  # noqa: BLE001 - auditoria não pode quebrar o fluxo; registramos no log técnico
        logger.exception("Falha ao gravar auditoria (%s %s)", acao, entidade)


# ---------------------------------------------------------------------------
# Disponibilidade
# ---------------------------------------------------------------------------
def _duracao_da_janela(profissional, unidade, inicio):
    """
    Confere se 'inicio' cai exatamente num slot da grade do profissional naquela unidade.
    Retorna a duração (timedelta) do slot ou None se o horário não existe na grade.
    """
    local = timezone.localtime(inicio)
    janelas = HorarioAtendimento.objects.filter(
        profissional=profissional, unidade=unidade, dia_semana=local.weekday()
    )
    for h in janelas:
        duracao = timedelta(minutes=h.duracao_min)
        ini_janela = local.replace(hour=h.hora_inicio.hour, minute=h.hora_inicio.minute, second=0, microsecond=0)
        fim_janela = local.replace(hour=h.hora_fim.hour, minute=h.hora_fim.minute, second=0, microsecond=0)
        if local < ini_janela or local + duracao > fim_janela:
            continue
        if (local - ini_janela) % duracao == timedelta(0):  # alinhado ao início de um slot
            return duracao
    return None


def horarios_disponiveis(profissional, unidade, dia):
    """Lista os inícios de slots LIVRES (futuros e sem conflito) do profissional em 'dia'."""
    tz = timezone.get_current_timezone()
    inicio_dia = datetime.combine(dia, time.min, tzinfo=tz)
    fim_dia = inicio_dia + timedelta(days=1)

    ocupados = list(
        Agendamento.objects.filter(
            profissional=profissional, status__in=STATUS_ATIVOS, inicio__lt=fim_dia, fim__gt=inicio_dia
        ).values_list("inicio", "fim")
    )

    agora = timezone.now()
    livres = []
    janelas = HorarioAtendimento.objects.filter(
        profissional=profissional, unidade=unidade, dia_semana=dia.weekday()
    ).order_by("hora_inicio")
    for h in janelas:
        duracao = timedelta(minutes=h.duracao_min)
        atual = datetime.combine(dia, h.hora_inicio, tzinfo=tz)
        limite = datetime.combine(dia, h.hora_fim, tzinfo=tz)
        while atual + duracao <= limite:
            fim_slot = atual + duracao
            if atual > agora and not any(o_ini < fim_slot and o_fim > atual for o_ini, o_fim in ocupados):
                livres.append(atual)
            atual = fim_slot
    return livres


def _existe_conflito_profissional(profissional, inicio, fim, ignorar_id=None):
    # Dois intervalos se sobrepõem quando: inicioA < fimB  E  fimA > inicioB
    qs = Agendamento.objects.filter(
        profissional=profissional, status__in=STATUS_ATIVOS, inicio__lt=fim, fim__gt=inicio
    )
    if ignorar_id:
        qs = qs.exclude(pk=ignorar_id)
    return qs.exists()


def _paciente_ocupado(paciente, inicio, fim, ignorar_id=None):
    # Regra extra: o mesmo paciente não pode ter duas consultas ao mesmo tempo.
    qs = Agendamento.objects.filter(paciente=paciente, status__in=STATUS_ATIVOS, inicio__lt=fim, fim__gt=inicio)
    if ignorar_id:
        qs = qs.exclude(pk=ignorar_id)
    return qs.exists()


MSG_CONFLITO = "Este horário acabou de ser ocupado. Escolha outro horário."


# ---------------------------------------------------------------------------
# Operações
# ---------------------------------------------------------------------------
def criar_agendamento(*, paciente, profissional, unidade, inicio, usuario, ip=None, observacao=""):
    if not (paciente.ativo and profissional.ativo and unidade.ativa):
        raise RegraNegocioError("Paciente, profissional ou unidade inativo.")
    if inicio <= timezone.now():
        raise RegraNegocioError("Não é possível agendar no passado.")
    duracao = _duracao_da_janela(profissional, unidade, inicio)
    if duracao is None:
        raise RegraNegocioError("Horário fora da agenda do profissional nesta unidade.")
    fim = inicio + duracao

    try:
        with transaction.atomic():
            # Trava a linha do profissional: requisições simultâneas para o mesmo profissional
            # esperam aqui umas pelas outras (em SQLite o comando é ignorado, sem efeito).
            Profissional.objects.select_for_update().get(pk=profissional.pk)
            if _existe_conflito_profissional(profissional, inicio, fim):
                raise ConflitoHorarioError(MSG_CONFLITO)
            if _paciente_ocupado(paciente, inicio, fim):
                raise ConflitoHorarioError("O paciente já possui outra consulta neste horário.")
            ag = Agendamento.objects.create(
                paciente=paciente, profissional=profissional, unidade=unidade,
                inicio=inicio, fim=fim, observacao=observacao,
                criado_por=usuario if getattr(usuario, "is_authenticated", False) else None,
            )
            registrar_auditoria(
                usuario=usuario, acao="AGENDAMENTO_CRIADO", entidade="Agendamento", entidade_id=ag.pk, ip=ip,
                detalhe=f"profissional={profissional.pk} unidade={unidade.pk} inicio={inicio.isoformat()}",
            )
    except IntegrityError as exc:
        # A restrição de exclusão do PostgreSQL recusou a gravação (corrida entre requisições).
        raise ConflitoHorarioError(MSG_CONFLITO) from exc
    return ag


def cancelar_agendamento(ag, *, usuario, ip=None, motivo=""):
    with transaction.atomic():
        ag = Agendamento.objects.select_for_update().get(pk=ag.pk)
        if ag.status not in STATUS_ATIVOS:
            raise RegraNegocioError("Somente agendamentos ativos podem ser cancelados.")
        ag.status = Status.CANCELADO
        ag.save(update_fields=["status", "atualizado_em"])
        registrar_auditoria(
            usuario=usuario, acao="AGENDAMENTO_CANCELADO", entidade="Agendamento", entidade_id=ag.pk, ip=ip,
            detalhe=f"motivo={motivo[:200]}",
        )
    return ag


def reagendar_agendamento(ag, novo_inicio, *, usuario, ip=None):
    if novo_inicio <= timezone.now():
        raise RegraNegocioError("Não é possível reagendar para o passado.")
    try:
        with transaction.atomic():
            Profissional.objects.select_for_update().get(pk=ag.profissional_id)
            ag = Agendamento.objects.select_for_update().get(pk=ag.pk)
            if ag.status not in STATUS_ATIVOS:
                raise RegraNegocioError("Somente agendamentos ativos podem ser reagendados.")
            duracao = _duracao_da_janela(ag.profissional, ag.unidade, novo_inicio)
            if duracao is None:
                raise RegraNegocioError("Horário fora da agenda do profissional nesta unidade.")
            novo_fim = novo_inicio + duracao
            # ignorar_id: o próprio agendamento não conta como conflito consigo mesmo
            if _existe_conflito_profissional(ag.profissional, novo_inicio, novo_fim, ignorar_id=ag.pk):
                raise ConflitoHorarioError(MSG_CONFLITO)
            if _paciente_ocupado(ag.paciente, novo_inicio, novo_fim, ignorar_id=ag.pk):
                raise ConflitoHorarioError("O paciente já possui outra consulta neste horário.")
            antigo = ag.inicio
            ag.inicio, ag.fim = novo_inicio, novo_fim
            ag.save(update_fields=["inicio", "fim", "atualizado_em"])
            registrar_auditoria(
                usuario=usuario, acao="AGENDAMENTO_REAGENDADO", entidade="Agendamento", entidade_id=ag.pk, ip=ip,
                detalhe=f"de={antigo.isoformat()} para={novo_inicio.isoformat()}",
            )
    except IntegrityError as exc:
        raise ConflitoHorarioError(MSG_CONFLITO) from exc
    return ag


def atualizar_status(ag, novo_status, *, usuario, ip=None):
    with transaction.atomic():
        ag = Agendamento.objects.select_for_update().get(pk=ag.pk)
        if novo_status not in TRANSICOES.get(ag.status, set()):
            raise RegraNegocioError("Mudança de status não permitida para este agendamento.")
        if novo_status in (Status.CONCLUIDO, Status.FALTOU) and ag.inicio > timezone.now():
            raise RegraNegocioError("Só é possível concluir ou marcar falta depois do horário da consulta.")
        anterior = ag.status
        ag.status = novo_status
        ag.save(update_fields=["status", "atualizado_em"])
        registrar_auditoria(
            usuario=usuario, acao="STATUS_ATUALIZADO", entidade="Agendamento", entidade_id=ag.pk, ip=ip,
            detalhe=f"{anterior} -> {novo_status}",
        )
    return ag
