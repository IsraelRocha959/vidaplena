from django.urls import path

from . import views

app_name = "agenda"

urlpatterns = [
    path("", views.agendamento_lista, name="lista"),
    path("agendamentos/novo/", views.agendamento_novo, name="novo"),
    path("agendamentos/<int:pk>/", views.agendamento_detalhe, name="detalhe"),
    path("agendamentos/<int:pk>/cancelar/", views.agendamento_cancelar, name="cancelar"),
    path("agendamentos/<int:pk>/reagendar/", views.agendamento_reagendar, name="reagendar"),
    path("agendamentos/<int:pk>/status/", views.agendamento_status, name="status"),
    path("pacientes/", views.paciente_lista, name="pacientes"),
    path("pacientes/novo/", views.paciente_form, name="paciente_novo"),
    path("pacientes/<int:pk>/editar/", views.paciente_form, name="paciente_editar"),
    path("auditoria/", views.auditoria_lista, name="auditoria"),
]
