"""Formulários. Toda entrada do usuário é validada AQUI e no servidor (nunca só no navegador)."""
import re

from django import forms
from django.utils import timezone

from .models import Papel, Paciente, Profissional, Status, Unidade, validar_cpf
from .permissions import papel_do_usuario, unidade_do_usuario


class BuscaDisponibilidadeForm(forms.Form):
    profissional = forms.ModelChoiceField(queryset=Profissional.objects.filter(ativo=True), label="Profissional")
    unidade = forms.ModelChoiceField(queryset=Unidade.objects.filter(ativa=True), label="Unidade")
    data = forms.DateField(label="Data", widget=forms.DateInput(attrs={"type": "date"}))

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        # Recepção só enxerga a própria unidade (menor privilégio também na interface).
        if user is not None and papel_do_usuario(user) == Papel.RECEPCAO:
            unidade = unidade_do_usuario(user)
            self.fields["unidade"].queryset = Unidade.objects.filter(pk=unidade.pk if unidade else None)

    def clean_data(self):
        data = self.cleaned_data["data"]
        if data < timezone.localdate():
            raise forms.ValidationError("Escolha uma data de hoje em diante.")
        return data


class ConfirmarAgendamentoForm(forms.Form):
    """Recebe a escolha do horário. 'inicio' chega em ISO 8601 (ex.: 2026-11-16T09:00:00-03:00)."""

    profissional = forms.ModelChoiceField(queryset=Profissional.objects.filter(ativo=True))
    unidade = forms.ModelChoiceField(queryset=Unidade.objects.filter(ativa=True))
    inicio = forms.DateTimeField()
    cpf_paciente = forms.CharField(required=False, max_length=14)

    def clean_cpf_paciente(self):
        return re.sub(r"\D", "", self.cleaned_data.get("cpf_paciente", ""))


class ReagendarForm(forms.Form):
    inicio = forms.DateTimeField()


class CancelamentoForm(forms.Form):
    motivo = forms.CharField(required=False, max_length=200)


class StatusForm(forms.Form):
    status = forms.ChoiceField(
        choices=[(Status.CONFIRMADO, "Confirmado"), (Status.CONCLUIDO, "Concluído"), (Status.FALTOU, "Faltou")]
    )


class PacienteForm(forms.ModelForm):
    # Campo redeclarado para aceitar máscara (14 caracteres); normalizamos para só dígitos.
    cpf = forms.CharField(label="CPF", max_length=14)

    class Meta:
        model = Paciente
        fields = ["nome", "cpf", "data_nascimento", "telefone", "email", "consentimento_lgpd"]
        labels = {"consentimento_lgpd": "O titular consentiu o tratamento dos seus dados (LGPD)"}
        widgets = {"data_nascimento": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")}

    def clean_cpf(self):
        digitos = re.sub(r"\D", "", self.cleaned_data["cpf"])
        validar_cpf(digitos)
        return digitos

    def clean_data_nascimento(self):
        d = self.cleaned_data["data_nascimento"]
        if d > timezone.localdate():
            raise forms.ValidationError("A data de nascimento não pode ser futura.")
        return d

    def clean_consentimento_lgpd(self):
        if not self.cleaned_data["consentimento_lgpd"]:
            raise forms.ValidationError("O registro do consentimento é obrigatório para cadastrar o paciente.")
        return True

    def save(self, commit=True):
        obj = super().save(commit=False)
        if obj.consentimento_lgpd and not obj.consentimento_em:
            obj.consentimento_em = timezone.now()
        if commit:
            obj.save()
        return obj
