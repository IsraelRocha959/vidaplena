"""
Modelo de dados da aplicação de agendamento.

Entidades (ver docs/MODELO_DE_DADOS.md para o diagrama):
  Unidade, Perfil (papel do usuário), Paciente, Profissional,
  HorarioAtendimento (grade semanal), Agendamento e RegistroAuditoria.
"""
import re

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import F, Q


# ---------------------------------------------------------------------------
# Validadores
# ---------------------------------------------------------------------------
def validar_cpf(valor: str) -> None:
    """Valida CPF pelo algoritmo dos dígitos verificadores (aceita com ou sem máscara)."""
    digitos = re.sub(r"\D", "", valor or "")
    if len(digitos) != 11 or digitos == digitos[0] * 11:
        raise ValidationError("CPF inválido.")
    for i in (9, 10):
        soma = sum(int(digitos[n]) * ((i + 1) - n) for n in range(i))
        digito = (soma * 10 % 11) % 10
        if digito != int(digitos[i]):
            raise ValidationError("CPF inválido.")


# ---------------------------------------------------------------------------
# Perfis de acesso (RBAC - Role Based Access Control)
# ---------------------------------------------------------------------------
class Papel(models.TextChoices):
    ADMIN = "ADMIN", "Administrador"
    RECEPCAO = "RECEPCAO", "Recepção"
    PROFISSIONAL = "PROFISSIONAL", "Profissional de saúde"
    PACIENTE = "PACIENTE", "Paciente"


class Unidade(models.Model):
    nome = models.CharField(max_length=120, unique=True)
    endereco = models.CharField(max_length=255)
    ativa = models.BooleanField(default=True)

    class Meta:
        ordering = ["nome"]

    def __str__(self):
        return self.nome


class Perfil(models.Model):
    """Liga um usuário do Django (login) ao seu papel e, para a recepção, à sua unidade."""

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="perfil")
    papel = models.CharField(max_length=20, choices=Papel.choices)
    unidade = models.ForeignKey(
        Unidade, null=True, blank=True, on_delete=models.PROTECT,
        help_text="Obrigatória para a Recepção: limita o acesso à unidade.",
    )

    def clean(self):
        if self.papel == Papel.RECEPCAO and not self.unidade_id:
            raise ValidationError({"unidade": "A recepção precisa estar vinculada a uma unidade."})

    def __str__(self):
        return f"{self.user.get_username()} ({self.get_papel_display()})"


# ---------------------------------------------------------------------------
# Cadastros
# ---------------------------------------------------------------------------
class Paciente(models.Model):
    nome = models.CharField(max_length=150)
    # CPF guardado só com dígitos, único: evita o mesmo paciente cadastrado duas vezes.
    cpf = models.CharField(max_length=11, unique=True, validators=[validar_cpf])
    data_nascimento = models.DateField()
    telefone = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    # Vínculo opcional com um login (para o paciente consultar os próprios agendamentos).
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="paciente"
    )
    # LGPD: registro do consentimento do titular (data/hora).
    consentimento_lgpd = models.BooleanField(default=False)
    consentimento_em = models.DateTimeField(null=True, blank=True)
    ativo = models.BooleanField(default=True)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["nome"]

    def save(self, *args, **kwargs):
        self.cpf = re.sub(r"\D", "", self.cpf or "")  # normaliza sempre
        super().save(*args, **kwargs)

    @property
    def cpf_mascarado(self) -> str:
        """Minimização de dados: telas de listagem não exibem o CPF completo."""
        c = self.cpf
        return f"***.{c[3:6]}.{c[6:9]}-**" if len(c) == 11 else "***"

    def __str__(self):
        return self.nome


class Profissional(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="profissional"
    )
    nome = models.CharField(max_length=150)
    especialidade = models.CharField(max_length=100)
    registro_profissional = models.CharField(max_length=30, blank=True, help_text="Ex.: CRM/SP 123456")
    unidades = models.ManyToManyField(Unidade, related_name="profissionais", blank=True)
    ativo = models.BooleanField(default=True)

    class Meta:
        ordering = ["nome"]
        verbose_name_plural = "profissionais"

    def __str__(self):
        return f"{self.nome} - {self.especialidade}"


class HorarioAtendimento(models.Model):
    """Grade semanal: em que dias/horas o profissional atende em cada unidade."""

    DIAS = [(0, "Segunda"), (1, "Terça"), (2, "Quarta"), (3, "Quinta"), (4, "Sexta"), (5, "Sábado"), (6, "Domingo")]

    profissional = models.ForeignKey(Profissional, on_delete=models.CASCADE, related_name="horarios")
    unidade = models.ForeignKey(Unidade, on_delete=models.CASCADE)
    dia_semana = models.PositiveSmallIntegerField(choices=DIAS)  # 0 = segunda (padrão do Python)
    hora_inicio = models.TimeField()
    hora_fim = models.TimeField()
    duracao_min = models.PositiveSmallIntegerField(default=30, help_text="Duração de cada consulta (minutos).")

    class Meta:
        ordering = ["dia_semana", "hora_inicio"]
        verbose_name = "horário de atendimento"
        verbose_name_plural = "horários de atendimento"

    def clean(self):
        if self.hora_inicio and self.hora_fim and self.hora_fim <= self.hora_inicio:
            raise ValidationError("A hora final deve ser maior que a inicial.")
        if self.duracao_min is not None and self.duracao_min < 5:
            raise ValidationError("A duração mínima é de 5 minutos.")

    def __str__(self):
        return f"{self.profissional.nome} - {self.get_dia_semana_display()} {self.hora_inicio:%H:%M}-{self.hora_fim:%H:%M}"


# ---------------------------------------------------------------------------
# Agendamento
# ---------------------------------------------------------------------------
class Status(models.TextChoices):
    AGENDADO = "AGENDADO", "Agendado"
    CONFIRMADO = "CONFIRMADO", "Confirmado"
    CONCLUIDO = "CONCLUIDO", "Concluído"
    CANCELADO = "CANCELADO", "Cancelado"
    FALTOU = "FALTOU", "Faltou"


# Só estes status "ocupam" o horário. Cancelado/Faltou/Concluído liberam o slot
# para novas buscas (e a restrição do PostgreSQL também só considera estes).
STATUS_ATIVOS = (Status.AGENDADO, Status.CONFIRMADO)


class Agendamento(models.Model):
    paciente = models.ForeignKey(Paciente, on_delete=models.PROTECT, related_name="agendamentos")
    profissional = models.ForeignKey(Profissional, on_delete=models.PROTECT, related_name="agendamentos")
    unidade = models.ForeignKey(Unidade, on_delete=models.PROTECT, related_name="agendamentos")
    inicio = models.DateTimeField()
    fim = models.DateTimeField()
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.AGENDADO)
    observacao = models.CharField(
        max_length=200, blank=True,
        help_text="Uso administrativo. NÃO registrar informações clínicas.",
    )
    criado_por = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["inicio"]
        indexes = [
            models.Index(fields=["profissional", "inicio"]),  # acelera a checagem de conflito
            models.Index(fields=["status", "inicio"]),
        ]
        constraints = [
            # Garantia mínima válida em QUALQUER banco: o fim é sempre depois do início.
            models.CheckConstraint(condition=Q(fim__gt=F("inicio")), name="agendamento_fim_apos_inicio"),
        ]
        # + Em PostgreSQL, db_constraints.py cria a restrição de exclusão contra sobreposição.

    def __str__(self):
        return f"{self.paciente_id} com {self.profissional_id} em {self.inicio:%d/%m/%Y %H:%M}"

    @property
    def esta_ativo(self) -> bool:
        return self.status in STATUS_ATIVOS


# ---------------------------------------------------------------------------
# Auditoria (trilha de quem fez o quê)
# ---------------------------------------------------------------------------
class RegistroAuditoria(models.Model):
    """Registro imutável: cada operação relevante gera uma linha, nunca editada."""

    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    usuario_texto = models.CharField(max_length=150, blank=True)  # guarda o login mesmo se o usuário for apagado
    acao = models.CharField(max_length=40, db_index=True)
    entidade = models.CharField(max_length=40)
    entidade_id = models.CharField(max_length=40, blank=True)
    detalhe = models.TextField(blank=True)  # sem dados pessoais: IDs e estados
    ip = models.GenericIPAddressField(null=True, blank=True)
    criado_em = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-criado_em"]
        verbose_name = "registro de auditoria"
        verbose_name_plural = "registros de auditoria"

    def save(self, *args, **kwargs):
        if not self._state.adding:
            raise PermissionError("Registros de auditoria não podem ser alterados.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise PermissionError("Registros de auditoria não podem ser apagados.")

    def __str__(self):
        return f"{self.criado_em:%d/%m/%Y %H:%M} {self.acao} {self.entidade}#{self.entidade_id}"
