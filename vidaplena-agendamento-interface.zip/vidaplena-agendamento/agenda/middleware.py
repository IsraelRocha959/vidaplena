"""Cabeçalhos de segurança HTTP adicionais (defesa em profundidade)."""
from django.conf import settings
from django.utils.cache import add_never_cache_headers


class SecurityHeadersMiddleware:
    # CSP: só carrega recursos do próprio domínio; nenhum script/estilo inline.
    # (Por isso os templates NÃO usam <script> nem style="" inline.)
    CSP = (
        "default-src 'self'; img-src 'self' data:; frame-ancestors 'none'; "
        "base-uri 'self'; form-action 'self'"
    )

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        # O Django Admin e a página de erro do modo DEBUG usam estilos inline: não aplicamos CSP a eles.
        if not settings.DEBUG and not request.path.startswith("/gestao-admin/"):
            response.setdefault("Content-Security-Policy", self.CSP)
        response.setdefault("Permissions-Policy", "geolocation=(), camera=(), microphone=()")
        # Páginas de usuário logado contêm dados de saúde: proibir cache do navegador/proxies.
        user = getattr(request, "user", None)
        if user is not None and user.is_authenticated:
            add_never_cache_headers(response)
        return response
