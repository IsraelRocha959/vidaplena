"""
Restrição de EXCLUSÃO no PostgreSQL: a "última linha de defesa" contra conflito de horários.

Por que existe se o código já verifica conflito? Porque duas requisições simultâneas
podem passar juntas pela verificação (condição de corrida). O banco, porém, serializa
a gravação e RECUSA a segunda linha que sobreponha o intervalo do mesmo profissional.

Em SQLite (desenvolvimento) esta restrição não existe; a proteção fica na camada
de serviço (services.py) com transação. Os testes cobrem essa camada.
"""
import logging

from django.db import DEFAULT_DB_ALIAS, connections

logger = logging.getLogger(__name__)

SQL = """
CREATE EXTENSION IF NOT EXISTS btree_gist;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agendamento_sem_sobreposicao') THEN
        ALTER TABLE agenda_agendamento
            ADD CONSTRAINT agendamento_sem_sobreposicao
            EXCLUDE USING gist (
                profissional_id WITH =,
                tstzrange(inicio, fim) WITH &&
            ) WHERE (status IN ('AGENDADO', 'CONFIRMADO'));
    END IF;
END
$$;
"""


def criar_restricao_postgres(sender=None, using=DEFAULT_DB_ALIAS, **kwargs):
    conexao = connections[using]
    if conexao.vendor != "postgresql":
        return
    if "agenda_agendamento" not in conexao.introspection.table_names():
        return
    with conexao.cursor() as cursor:
        cursor.execute(SQL)
    logger.info("Restrição de exclusão de agendamentos garantida no PostgreSQL.")
