from django.apps import AppConfig
from django.db.models.signals import post_migrate


class AgendaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "agenda"
    verbose_name = "Agenda da Clínica"

    def ready(self):
        # Registra os "ouvintes" de eventos (login/logout -> auditoria)
        from . import signals  # noqa: F401
        from .db_constraints import criar_restricao_postgres

        # Depois do "migrate", cria a restrição anti-sobreposição (somente PostgreSQL).
        post_migrate.connect(criar_restricao_postgres, sender=self, dispatch_uid="agenda_restricao_pg")
