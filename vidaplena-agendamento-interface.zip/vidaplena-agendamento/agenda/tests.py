"""
Testes automatizados. Rodar com:  python manage.py test

Cobrem: regra de conflito de horário, grade de atendimento, cancelamento/reagendamento,
transições de status, validação de CPF, auditoria, controle de acesso por perfil
(inclusive IDOR entre unidades/pacientes) e bloqueio de força bruta no login.
"""
from datetime import datetime, time, timedelta

from django.contrib.auth.models import User
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .models import (
    Agendamento, HorarioAtendimento, Paciente, Papel, Perfil, Profissional, RegistroAuditoria, Status,
    Unidade, validar_cpf,
)
from .services import (
    ConflitoHorarioError, RegraNegocioError, atualizar_status, cancelar_agendamento, criar_agendamento,
    horarios_disponiveis, reagendar_agendamento,
)

SENHA = "Senha-Teste-12345!"
CPF_A, CPF_B = "52998224725", "11144477735"  # CPFs de teste válidos


def proxima_segunda():
    d = timezone.localdate() + timedelta(days=1)
    while d.weekday() != 0:
        d += timedelta(days=1)
    return d


def slot(dia, hora, minuto=0):
    return datetime.combine(dia, time(hora, minuto), tzinfo=timezone.get_current_timezone())


@override_settings(SECURE_SSL_REDIRECT=False, SESSION_COOKIE_SECURE=False, CSRF_COOKIE_SECURE=False)
class BaseTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.centro = Unidade.objects.create(nome="Centro", endereco="Rua A, 1")
        cls.norte = Unidade.objects.create(nome="Norte", endereco="Rua B, 2")

        def mk(login, papel, unidade=None):
            u = User.objects.create_user(login, password=SENHA)
            Perfil.objects.create(user=u, papel=papel, unidade=unidade)
            return u

        cls.u_admin = mk("admin1", Papel.ADMIN)
        cls.u_rec_centro = mk("rec_centro", Papel.RECEPCAO, cls.centro)
        cls.u_rec_norte = mk("rec_norte", Papel.RECEPCAO, cls.norte)
        cls.u_prof = mk("dr_silva", Papel.PROFISSIONAL)
        cls.u_prof2 = mk("dra_lima", Papel.PROFISSIONAL)
        cls.u_pac_a = mk("pac_a", Papel.PACIENTE)
        cls.u_pac_b = mk("pac_b", Papel.PACIENTE)

        cls.prof = Profissional.objects.create(user=cls.u_prof, nome="Dr. Silva", especialidade="Clínica")
        cls.prof2 = Profissional.objects.create(user=cls.u_prof2, nome="Dra. Lima", especialidade="Pediatria")
        for p in (cls.prof, cls.prof2):
            p.unidades.add(cls.centro)
            HorarioAtendimento.objects.create(  # segunda 08:00-12:00, 30 min
                profissional=p, unidade=cls.centro, dia_semana=0,
                hora_inicio=time(8, 0), hora_fim=time(12, 0), duracao_min=30,
            )
        cls.pac_a = Paciente.objects.create(
            nome="Paciente A", cpf=CPF_A, data_nascimento="1990-01-01", telefone="1", user=cls.u_pac_a,
            consentimento_lgpd=True,
        )
        cls.pac_b = Paciente.objects.create(
            nome="Paciente B", cpf=CPF_B, data_nascimento="1991-01-01", telefone="2", user=cls.u_pac_b,
            consentimento_lgpd=True,
        )
        cls.seg = proxima_segunda()

    def setUp(self):
        cache.clear()

    def agendar(self, paciente=None, profissional=None, hora=9, minuto=0):
        return criar_agendamento(
            paciente=paciente or self.pac_a, profissional=profissional or self.prof, unidade=self.centro,
            inicio=slot(self.seg, hora, minuto), usuario=self.u_rec_centro,
        )


class RegrasDeNegocioTests(BaseTest):
    def test_disponibilidade_gera_oito_slots(self):
        self.assertEqual(len(horarios_disponiveis(self.prof, self.centro, self.seg)), 8)

    def test_agendar_remove_slot_da_disponibilidade(self):
        self.agendar(hora=9)
        livres = horarios_disponiveis(self.prof, self.centro, self.seg)
        self.assertEqual(len(livres), 7)
        self.assertNotIn(slot(self.seg, 9), livres)

    def test_conflito_mesmo_profissional_e_bloqueado(self):
        self.agendar(paciente=self.pac_a, hora=9)
        with self.assertRaises(ConflitoHorarioError):
            self.agendar(paciente=self.pac_b, hora=9)
        self.assertEqual(Agendamento.objects.count(), 1)

    def test_paciente_nao_pode_ter_duas_consultas_simultaneas(self):
        self.agendar(paciente=self.pac_a, profissional=self.prof, hora=9)
        with self.assertRaises(ConflitoHorarioError):
            self.agendar(paciente=self.pac_a, profissional=self.prof2, hora=9)

    def test_horario_fora_da_grade_e_recusado(self):
        with self.assertRaises(RegraNegocioError):
            self.agendar(hora=7)       # antes do expediente
        with self.assertRaises(RegraNegocioError):
            self.agendar(hora=9, minuto=10)  # não alinhado ao slot de 30 min

    def test_nao_agenda_no_passado(self):
        passado = slot(timezone.localdate() - timedelta(days=7), 9)
        with self.assertRaises(RegraNegocioError):
            criar_agendamento(paciente=self.pac_a, profissional=self.prof, unidade=self.centro,
                              inicio=passado, usuario=self.u_admin)

    def test_cancelamento_libera_horario(self):
        ag = self.agendar(hora=9)
        cancelar_agendamento(ag, usuario=self.u_rec_centro, motivo="teste")
        ag.refresh_from_db()
        self.assertEqual(ag.status, Status.CANCELADO)
        self.assertIn(slot(self.seg, 9), horarios_disponiveis(self.prof, self.centro, self.seg))
        self.agendar(paciente=self.pac_b, hora=9)  # agora outro paciente consegue

    def test_nao_cancela_duas_vezes(self):
        ag = self.agendar()
        cancelar_agendamento(ag, usuario=self.u_admin)
        with self.assertRaises(RegraNegocioError):
            cancelar_agendamento(ag, usuario=self.u_admin)

    def test_reagendar_move_e_libera_horario_antigo(self):
        ag = self.agendar(hora=9)
        reagendar_agendamento(ag, slot(self.seg, 10), usuario=self.u_rec_centro)
        ag.refresh_from_db()
        self.assertEqual(timezone.localtime(ag.inicio).hour, 10)
        self.assertIn(slot(self.seg, 9), horarios_disponiveis(self.prof, self.centro, self.seg))

    def test_reagendar_para_horario_ocupado_falha(self):
        ag = self.agendar(paciente=self.pac_a, hora=9)
        self.agendar(paciente=self.pac_b, hora=10)
        with self.assertRaises(ConflitoHorarioError):
            reagendar_agendamento(ag, slot(self.seg, 10), usuario=self.u_admin)

    def test_transicoes_de_status(self):
        ag = self.agendar()
        atualizar_status(ag, Status.CONFIRMADO, usuario=self.u_rec_centro)
        with self.assertRaises(RegraNegocioError):  # consulta é no futuro: não pode concluir ainda
            atualizar_status(ag, Status.CONCLUIDO, usuario=self.u_rec_centro)
        with self.assertRaises(RegraNegocioError):  # cancelamento tem função própria
            atualizar_status(ag, Status.CANCELADO, usuario=self.u_rec_centro)

    def test_auditoria_registra_criacao(self):
        ag = self.agendar()
        self.assertTrue(RegistroAuditoria.objects.filter(acao="AGENDAMENTO_CRIADO", entidade_id=str(ag.pk)).exists())

    def test_auditoria_e_imutavel(self):
        self.agendar()
        reg = RegistroAuditoria.objects.first()
        with self.assertRaises(PermissionError):
            reg.save()
        with self.assertRaises(PermissionError):
            reg.delete()

    def test_validacao_de_cpf(self):
        validar_cpf("529.982.247-25")
        for invalido in ("111.111.111-11", "123", "529.982.247-26"):
            with self.assertRaises(ValidationError):
                validar_cpf(invalido)


class ControleDeAcessoTests(BaseTest):
    def test_anonimo_e_redirecionado_ao_login(self):
        r = self.client.get(reverse("agenda:lista"))
        self.assertEqual(r.status_code, 302)
        self.assertIn(reverse("login"), r["Location"])

    def test_paciente_ve_apenas_os_proprios_agendamentos(self):
        ag_a = self.agendar(paciente=self.pac_a, hora=9)
        ag_b = self.agendar(paciente=self.pac_b, hora=10)
        self.client.login(username="pac_a", password=SENHA)
        self.assertEqual(self.client.get(reverse("agenda:detalhe", args=[ag_a.pk])).status_code, 200)
        # IDOR: tentar abrir o agendamento de outro paciente devolve 404
        self.assertEqual(self.client.get(reverse("agenda:detalhe", args=[ag_b.pk])).status_code, 404)

    def test_recepcao_so_ve_a_propria_unidade(self):
        ag = self.agendar()
        self.client.login(username="rec_norte", password=SENHA)
        self.assertEqual(self.client.get(reverse("agenda:detalhe", args=[ag.pk])).status_code, 404)
        self.client.logout()
        self.client.login(username="rec_centro", password=SENHA)
        self.assertEqual(self.client.get(reverse("agenda:detalhe", args=[ag.pk])).status_code, 200)

    def test_profissional_ve_apenas_a_propria_agenda(self):
        ag = self.agendar(profissional=self.prof)
        self.client.login(username="dra_lima", password=SENHA)
        self.assertEqual(self.client.get(reverse("agenda:detalhe", args=[ag.pk])).status_code, 404)

    def test_paciente_nao_acessa_cadastro_de_pacientes_nem_auditoria(self):
        self.client.login(username="pac_a", password=SENHA)
        self.assertEqual(self.client.get(reverse("agenda:pacientes")).status_code, 403)
        self.assertEqual(self.client.get(reverse("agenda:auditoria")).status_code, 403)

    def test_profissional_nao_pode_cancelar(self):
        ag = self.agendar(profissional=self.prof)
        self.client.login(username="dr_silva", password=SENHA)
        r = self.client.post(reverse("agenda:cancelar", args=[ag.pk]))
        self.assertEqual(r.status_code, 403)
        ag.refresh_from_db()
        self.assertEqual(ag.status, Status.AGENDADO)

    def test_cancelar_exige_post(self):
        ag = self.agendar(paciente=self.pac_a)
        self.client.login(username="pac_a", password=SENHA)
        self.assertEqual(self.client.get(reverse("agenda:cancelar", args=[ag.pk])).status_code, 405)

    def test_csrf_e_exigido_nos_formularios(self):
        from django.test import Client
        c = Client(enforce_csrf_checks=True)
        c.login(username="pac_a", password=SENHA)
        ag = self.agendar(paciente=self.pac_a)
        self.assertEqual(c.post(reverse("agenda:cancelar", args=[ag.pk])).status_code, 403)

    def test_paciente_agenda_pelo_fluxo_web(self):
        self.client.login(username="pac_a", password=SENHA)
        r = self.client.post(reverse("agenda:novo"), {
            "profissional": self.prof.pk, "unidade": self.centro.pk, "inicio": slot(self.seg, 9).isoformat(),
        })
        self.assertEqual(r.status_code, 302)
        ag = Agendamento.objects.get()
        self.assertEqual(ag.paciente, self.pac_a)  # sempre para si mesmo, ignorando qualquer CPF enviado

    def test_recepcao_nao_agenda_em_outra_unidade(self):
        self.client.login(username="rec_norte", password=SENHA)
        r = self.client.post(reverse("agenda:novo"), {
            "profissional": self.prof.pk, "unidade": self.centro.pk,
            "inicio": slot(self.seg, 9).isoformat(), "cpf_paciente": CPF_A,
        })
        self.assertEqual(r.status_code, 403)
        self.assertEqual(Agendamento.objects.count(), 0)

    def test_login_bloqueia_apos_tentativas_invalidas(self):
        for _ in range(5):
            self.client.post(reverse("login"), {"username": "pac_a", "password": "errada"})
        # Mesmo com a senha correta, fica bloqueado durante a janela de bloqueio.
        r = self.client.post(reverse("login"), {"username": "pac_a", "password": SENHA})
        self.assertEqual(r.status_code, 429)
        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertTrue(RegistroAuditoria.objects.filter(acao="LOGIN_BLOQUEADO").exists())

    def test_login_correto_funciona_e_e_auditado(self):
        r = self.client.post(reverse("login"), {"username": "pac_a", "password": SENHA})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(RegistroAuditoria.objects.filter(acao="LOGIN").exists())
