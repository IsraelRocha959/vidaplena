"""
AUTORIZAÇÃO (quem pode fazer o quê).

Duas camadas, ambas aplicadas NO SERVIDOR (esconder um botão na tela não é segurança):
  1) Nível de função: o decorador @papel_requerido barra papéis não autorizados (HTTP 403).
  2) Nível de objeto: agendamentos_visiveis() só devolve registros que o usuário pode ver.
     Acessar o ID de outra pessoa retorna 404 (e não 403), para não revelar que ele existe.
     Isso evita IDOR / "Broken Access Control" (OWASP A01).

Princípio do MENOR PRIVILÉGIO: papel desconhecido ou recepção sem unidade => sem acesso.
"""
from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import ObjectDoesNotExist, PermissionDenied

from .models import Agendamento, Papel
from .services import registrar_auditoria

TODOS = (Papel.ADMIN, Papel.RECEPCAO, Papel.PROFISSIONAL, Papel.PACIENTE)


def papel_do_usuario(user):
    if not user.is_authenticated:
        return None
    if user.is_superuser:
        return Papel.ADMIN
    try:
        return user.perfil.papel
    except ObjectDoesNotExist:
        return None  # usuário sem perfil não acessa nada


def unidade_do_usuario(user):
    try:
        return user.perfil.unidade
    except ObjectDoesNotExist:
        return None


def papel_requerido(*papeis):
    """Exige login e que o papel do usuário esteja em 'papeis'; senão HTTP 403 + auditoria."""

    def decorador(view):
        @wraps(view)
        def interna(request, *args, **kwargs):
            if papel_do_usuario(request.user) not in papeis:
                registrar_auditoria(
                    usuario=request.user, acao="ACESSO_NEGADO", entidade="Rota", detalhe=request.path[:200],
                    ip=request.META.get("REMOTE_ADDR"),
                )
                raise PermissionDenied
            return view(request, *args, **kwargs)

        return login_required(interna)

    return decorador


def agendamentos_visiveis(user):
    """QuerySet de agendamentos que ESTE usuário pode enxergar."""
    papel = papel_do_usuario(user)
    qs = Agendamento.objects.select_related("paciente", "profissional", "unidade")
    if papel == Papel.ADMIN:
        return qs
    if papel == Papel.RECEPCAO:
        unidade = unidade_do_usuario(user)
        return qs.filter(unidade=unidade) if unidade else qs.none()
    if papel == Papel.PROFISSIONAL:
        return qs.filter(profissional__user=user)
    if papel == Papel.PACIENTE:
        return qs.filter(paciente__user=user)
    return qs.none()


def acoes_permitidas(user, ag):
    """Ações que o usuário pode executar sobre UM agendamento (já visível para ele)."""
    papel = papel_do_usuario(user)
    if not ag.esta_ativo:
        return set()
    if papel in (Papel.ADMIN, Papel.RECEPCAO):
        return {"cancelar", "reagendar", "status"}
    if papel == Papel.PROFISSIONAL:
        return {"status"}
    if papel == Papel.PACIENTE:
        return {"cancelar", "reagendar"}
    return set()
