"""
CAMADA DE APRESENTAÇÃO (views). Regra geral: a view valida entrada, checa PERMISSÃO,
chama a camada de serviço e devolve a resposta. Nenhuma regra de negócio fica aqui.
"""
import logging
from datetime import timedelta
from urllib.parse import urlencode

from django.contrib import messages
from django.contrib.auth.views import LoginView
from django.core.cache import cache
from django.conf import settings
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.dateparse import parse_date
from django.views.decorators.http import require_POST

from .forms import (
    BuscaDisponibilidadeForm, CancelamentoForm, ConfirmarAgendamentoForm, PacienteForm,
    ReagendarForm, StatusForm,
)
from .models import Paciente, Papel, RegistroAuditoria, Status
from .permissions import (
    TODOS, acoes_permitidas, agendamentos_visiveis, papel_do_usuario, papel_requerido, unidade_do_usuario,
)
from .services import (
    RegraNegocioError, atualizar_status, cancelar_agendamento, criar_agendamento, horarios_disponiveis,
    reagendar_agendamento, registrar_auditoria,
)

logger = logging.getLogger(__name__)


def _ip(request):
    return request.META.get("REMOTE_ADDR")


# ---------------------------------------------------------------------------
# Autenticação com limite de tentativas (mitiga força bruta / credential stuffing)
# ---------------------------------------------------------------------------
class LoginComLimite(LoginView):
    """
    Após LOGIN_MAX_TENTATIVAS falhas para o mesmo (usuário + IP), bloqueia novas tentativas
    por LOGIN_BLOQUEIO_SEGUNDOS, mesmo que a senha correta seja enviada depois.
    O contador usa o cache do Django (em produção: Redis, compartilhado entre processos).
    """

    redirect_authenticated_user = True

    def _chave(self, request):
        usuario = (request.POST.get("username") or "").strip().lower()[:150]
        return f"login-falhas:{_ip(request)}:{usuario}"

    def post(self, request, *args, **kwargs):
        if cache.get(self._chave(request), 0) >= settings.LOGIN_MAX_TENTATIVAS:
            registrar_auditoria(
                usuario_texto=request.POST.get("username", "")[:150], acao="LOGIN_BLOQUEADO",
                entidade="Usuario", ip=_ip(request),
            )
            form = self.get_form()
            form.add_error(None, "Muitas tentativas. Aguarde alguns minutos e tente novamente.")
            return self.render_to_response(self.get_context_data(form=form), status=429)
        return super().post(request, *args, **kwargs)

    def form_invalid(self, form):
        chave = self._chave(self.request)
        cache.add(chave, 0, settings.LOGIN_BLOQUEIO_SEGUNDOS)  # cria o contador se ainda não existe
        try:
            cache.incr(chave)
        except ValueError:
            cache.set(chave, 1, settings.LOGIN_BLOQUEIO_SEGUNDOS)
        return super().form_invalid(form)

    def form_valid(self, form):
        cache.delete(self._chave(self.request))  # login correto zera o contador
        return super().form_valid(form)


# ---------------------------------------------------------------------------
# Agendamentos
# ---------------------------------------------------------------------------
@papel_requerido(*TODOS)
def agendamento_lista(request):
    qs = agendamentos_visiveis(request.user)  # JÁ filtrado pelo que o usuário pode ver
    data = parse_date(request.GET.get("data", "") or "")
    status = request.GET.get("status", "")
    if data:
        qs = qs.filter(inicio__date=data)
    if status in Status.values:
        qs = qs.filter(status=status)
    pagina = Paginator(qs, 20).get_page(request.GET.get("pagina"))
    return render(request, "agenda/lista.html", {
        "pagina": pagina, "status_opcoes": Status.choices,
        "f_data": request.GET.get("data", ""), "f_status": status,
    })


def _resolver_paciente(user, papel, cpf):
    """Paciente logado agenda para si; equipe informa o CPF (sem listar todos os pacientes)."""
    if papel == Papel.PACIENTE:
        paciente = Paciente.objects.filter(user=user, ativo=True).first()
        if not paciente:
            raise RegraNegocioError("Seu login não está vinculado a um cadastro de paciente.")
        return paciente
    if len(cpf) != 11:
        raise RegraNegocioError("Informe o CPF do paciente (11 dígitos).")
    paciente = Paciente.objects.filter(cpf=cpf, ativo=True).first()
    if not paciente:
        raise RegraNegocioError("Paciente não encontrado. Faça o cadastro antes de agendar.")
    return paciente


@papel_requerido(*[Papel.ADMIN, Papel.RECEPCAO, Papel.PACIENTE])
def agendamento_novo(request):
    papel = papel_do_usuario(request.user)

    # ---- Passo 2: confirmação do horário escolhido (POST) ----
    if request.method == "POST":
        form = ConfirmarAgendamentoForm(request.POST)
        if not form.is_valid():
            messages.error(request, "Dados inválidos. Refaça a busca e escolha um horário.")
            return redirect("agenda:novo")
        cd = form.cleaned_data
        if papel == Papel.RECEPCAO and cd["unidade"] != unidade_do_usuario(request.user):
            raise PermissionDenied  # recepção não agenda em outra unidade
        voltar = reverse("agenda:novo") + "?" + urlencode({
            "profissional": cd["profissional"].pk, "unidade": cd["unidade"].pk,
            "data": timezone.localtime(cd["inicio"]).date().isoformat(),
        })
        try:
            paciente = _resolver_paciente(request.user, papel, cd["cpf_paciente"])
            ag = criar_agendamento(
                paciente=paciente, profissional=cd["profissional"], unidade=cd["unidade"],
                inicio=cd["inicio"], usuario=request.user, ip=_ip(request),
            )
        except RegraNegocioError as erro:
            messages.error(request, str(erro))
            return redirect(voltar)
        messages.success(request, "Agendamento realizado com sucesso.")
        return redirect("agenda:detalhe", pk=ag.pk)

    # ---- Passo 1: busca de disponibilidade (GET) ----
    busca = BuscaDisponibilidadeForm(request.GET or None, user=request.user)
    slots = None
    if request.GET and busca.is_valid():
        cd = busca.cleaned_data
        slots = horarios_disponiveis(cd["profissional"], cd["unidade"], cd["data"])
    return render(request, "agenda/novo.html", {"busca": busca, "slots": slots})


@papel_requerido(*TODOS)
def agendamento_detalhe(request, pk):
    # get_object_or_404 sobre o queryset FILTRADO: ID de outra pessoa => 404 (anti-IDOR).
    ag = get_object_or_404(agendamentos_visiveis(request.user), pk=pk)
    return render(request, "agenda/detalhe.html", {
        "ag": ag, "acoes": acoes_permitidas(request.user, ag),
        "status_form": StatusForm(), "cancel_form": CancelamentoForm(),
    })


@papel_requerido(*TODOS)
@require_POST
def agendamento_cancelar(request, pk):
    ag = get_object_or_404(agendamentos_visiveis(request.user), pk=pk)
    if "cancelar" not in acoes_permitidas(request.user, ag):
        raise PermissionDenied
    form = CancelamentoForm(request.POST)
    motivo = form.cleaned_data["motivo"] if form.is_valid() else ""
    try:
        cancelar_agendamento(ag, usuario=request.user, ip=_ip(request), motivo=motivo)
        messages.success(request, "Agendamento cancelado. O horário foi liberado.")
    except RegraNegocioError as erro:
        messages.error(request, str(erro))
    return redirect("agenda:detalhe", pk=ag.pk)


@papel_requerido(*TODOS)
def agendamento_reagendar(request, pk):
    ag = get_object_or_404(agendamentos_visiveis(request.user), pk=pk)
    if "reagendar" not in acoes_permitidas(request.user, ag):
        raise PermissionDenied

    if request.method == "POST":
        form = ReagendarForm(request.POST)
        if form.is_valid():
            try:
                reagendar_agendamento(ag, form.cleaned_data["inicio"], usuario=request.user, ip=_ip(request))
                messages.success(request, "Agendamento reagendado com sucesso.")
                return redirect("agenda:detalhe", pk=ag.pk)
            except RegraNegocioError as erro:
                messages.error(request, str(erro))
        else:
            messages.error(request, "Escolha um horário válido.")
        return redirect("agenda:reagendar", pk=ag.pk)

    data = parse_date(request.GET.get("data", "") or "") or (timezone.localdate() + timedelta(days=1))
    slots = horarios_disponiveis(ag.profissional, ag.unidade, data) if data >= timezone.localdate() else []
    return render(request, "agenda/reagendar.html", {"ag": ag, "data": data, "slots": slots})


@papel_requerido(Papel.ADMIN, Papel.RECEPCAO, Papel.PROFISSIONAL)
@require_POST
def agendamento_status(request, pk):
    ag = get_object_or_404(agendamentos_visiveis(request.user), pk=pk)
    if "status" not in acoes_permitidas(request.user, ag):
        raise PermissionDenied
    form = StatusForm(request.POST)
    if form.is_valid():
        try:
            atualizar_status(ag, form.cleaned_data["status"], usuario=request.user, ip=_ip(request))
            messages.success(request, "Status atualizado.")
        except RegraNegocioError as erro:
            messages.error(request, str(erro))
    else:
        messages.error(request, "Status inválido.")
    return redirect("agenda:detalhe", pk=ag.pk)


# ---------------------------------------------------------------------------
# Pacientes (Recepção e Administrador)
# ---------------------------------------------------------------------------
@papel_requerido(Papel.ADMIN, Papel.RECEPCAO)
def paciente_lista(request):
    termo = (request.GET.get("q") or "").strip()
    qs = Paciente.objects.all()
    if termo:
        digitos = "".join(c for c in termo if c.isdigit())
        filtro = Q(nome__icontains=termo)
        if digitos:
            filtro |= Q(cpf=digitos)  # busca exata por CPF: não permite "varrer" CPFs parciais
        qs = qs.filter(filtro)
    pagina = Paginator(qs, 20).get_page(request.GET.get("pagina"))
    return render(request, "agenda/pacientes_lista.html", {"pagina": pagina, "q": termo})


@papel_requerido(Papel.ADMIN, Papel.RECEPCAO)
def paciente_form(request, pk=None):
    paciente = get_object_or_404(Paciente, pk=pk) if pk else None
    form = PacienteForm(request.POST or None, instance=paciente)
    if request.method == "POST" and form.is_valid():
        obj = form.save()
        registrar_auditoria(
            usuario=request.user, acao="PACIENTE_ALTERADO" if paciente else "PACIENTE_CRIADO",
            entidade="Paciente", entidade_id=obj.pk, ip=_ip(request),  # sem dados pessoais no log
        )
        messages.success(request, "Paciente salvo com sucesso.")
        return redirect("agenda:pacientes")
    return render(request, "agenda/paciente_form.html", {"form": form, "paciente": paciente})


# ---------------------------------------------------------------------------
# Auditoria (somente Administrador)
# ---------------------------------------------------------------------------
@papel_requerido(Papel.ADMIN)
def auditoria_lista(request):
    qs = RegistroAuditoria.objects.all()
    acao = (request.GET.get("acao") or "").strip().upper()
    if acao:
        qs = qs.filter(acao=acao)
    pagina = Paginator(qs, 50).get_page(request.GET.get("pagina"))
    return render(request, "agenda/auditoria.html", {"pagina": pagina, "acao": acao})


# ---------------------------------------------------------------------------
# Tratamento de erros: páginas amigáveis, sem vazar detalhes técnicos
# ---------------------------------------------------------------------------
def erro_403(request, exception=None):
    return render(request, "403.html", status=403)


def erro_404(request, exception=None):
    return render(request, "404.html", status=404)


def erro_500(request):
    # Página estática simples: se o erro for no banco/template, não depende deles.
    from django.http import HttpResponseServerError
    from django.template import loader

    return HttpResponseServerError(loader.render_to_string("500.html"))
