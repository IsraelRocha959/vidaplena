"""Auditoria automática de autenticação: login, logout e tentativas inválidas."""
import logging

from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.dispatch import receiver

from .services import registrar_auditoria

logger = logging.getLogger(__name__)


def _ip(request):
    # REMOTE_ADDR é o IP da conexão. Atrás de proxy, configure o proxy para repassar o IP real
    # e só então confie em X-Forwarded-For (cabeçalho forjável se aceito sem critério).
    return request.META.get("REMOTE_ADDR") if request is not None else None


@receiver(user_logged_in, dispatch_uid="auditar_login")
def auditar_login(sender, request, user, **kwargs):
    registrar_auditoria(usuario=user, acao="LOGIN", entidade="Usuario", entidade_id=str(user.pk), ip=_ip(request))


@receiver(user_logged_out, dispatch_uid="auditar_logout")
def auditar_logout(sender, request, user, **kwargs):
    if user is not None:
        registrar_auditoria(usuario=user, acao="LOGOUT", entidade="Usuario", entidade_id=str(user.pk), ip=_ip(request))


@receiver(user_login_failed, dispatch_uid="auditar_login_falhou")
def auditar_login_falhou(sender, credentials, request=None, **kwargs):
    # Registramos só o NOME DE USUÁRIO tentado. A senha digitada jamais é gravada.
    login = str(credentials.get("username", ""))[:150]
    registrar_auditoria(usuario=None, usuario_texto=login, acao="LOGIN_FALHOU", entidade="Usuario", ip=_ip(request))
