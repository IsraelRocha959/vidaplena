"""Disponibiliza o papel do usuário em todos os templates (para montar o menu)."""
from .models import Papel
from .permissions import papel_do_usuario


def papel_usuario(request):
    papel = papel_do_usuario(request.user) if hasattr(request, "user") else None
    return {
        "papel": papel,
        "pode_agendar": papel in (Papel.ADMIN, Papel.RECEPCAO, Papel.PACIENTE),
        "pode_gerir_pacientes": papel in (Papel.ADMIN, Papel.RECEPCAO),
        "e_admin": papel == Papel.ADMIN,
    }
