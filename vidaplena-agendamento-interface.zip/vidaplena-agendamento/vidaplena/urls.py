"""Rotas raiz. O painel administrativo fica em /gestao-admin/ (e não em /admin/) para
reduzir varreduras automáticas; isso NÃO substitui autenticação forte."""
from django.contrib import admin
from django.contrib.auth.views import LogoutView
from django.urls import include, path

from agenda.views import LoginComLimite

urlpatterns = [
    path("gestao-admin/", admin.site.urls),
    # Login com limite de tentativas; logout exige POST (protegido por CSRF).
    path("entrar/", LoginComLimite.as_view(template_name="registration/login.html"), name="login"),
    path("sair/", LogoutView.as_view(), name="logout"),
    path("", include("agenda.urls")),
]

handler403 = "agenda.views.erro_403"
handler404 = "agenda.views.erro_404"
handler500 = "agenda.views.erro_500"
