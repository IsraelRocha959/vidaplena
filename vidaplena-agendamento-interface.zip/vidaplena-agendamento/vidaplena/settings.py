"""
Configurações do projeto Vida Plena (Django 5.2).

PRINCÍPIO DE SEGURANÇA DESTE ARQUIVO
------------------------------------
Segredos (SECRET_KEY, senha do banco) NUNCA ficam no código: vêm de variáveis de
ambiente ou do arquivo .env (ignorado pelo Git). Os controles de transporte
(HTTPS, HSTS, cookies "Secure") ficam LIGADOS por padrão e só são relaxados
quando DJANGO_DEBUG=1 (desenvolvimento local, em http://localhost).
"""
import os
from pathlib import Path

from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent


# --------------------------------------------------------------------------
# Leitura do .env (mini-carregador, evita dependência extra)
# --------------------------------------------------------------------------
def _carregar_env(caminho: Path) -> None:
    """Lê linhas CHAVE=valor do .env sem sobrescrever variáveis já definidas."""
    if not caminho.exists():
        return
    for linha in caminho.read_text(encoding="utf-8").splitlines():
        linha = linha.strip()
        if not linha or linha.startswith("#") or "=" not in linha:
            continue
        chave, _, valor = linha.partition("=")
        os.environ.setdefault(chave.strip(), valor.strip().strip('"').strip("'"))


_carregar_env(BASE_DIR / ".env")


def _bool(nome: str, padrao: bool = False) -> bool:
    return os.environ.get(nome, str(padrao)).strip().lower() in ("1", "true", "sim", "yes", "on")


def _lista(nome: str, padrao: str = "") -> list[str]:
    return [i.strip() for i in os.environ.get(nome, padrao).split(",") if i.strip()]


# --------------------------------------------------------------------------
# Núcleo
# --------------------------------------------------------------------------
DEBUG = _bool("DJANGO_DEBUG", False)  # Padrão SEGURO: desligado.

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "")
if not SECRET_KEY:
    if DEBUG:
        SECRET_KEY = "chave-de-desenvolvimento-insegura"  # só para uso local
    else:
        raise ImproperlyConfigured(
            "Defina DJANGO_SECRET_KEY (ex.: python -c \"import secrets; print(secrets.token_urlsafe(50))\")."
        )

ALLOWED_HOSTS = _lista("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1")
CSRF_TRUSTED_ORIGINS = _lista("DJANGO_CSRF_TRUSTED_ORIGINS")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "agenda.apps.AgendaConfig",
]

# A ORDEM IMPORTA. SecurityMiddleware primeiro (redirecionamento HTTPS e HSTS);
# CSRF antes da autenticação; nosso middleware de cabeçalhos por último (precisa de request.user).
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "agenda.middleware.SecurityHeadersMiddleware",
]

ROOT_URLCONF = "vidaplena.urls"
WSGI_APPLICATION = "vidaplena.wsgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "agenda.context_processors.papel_usuario",  # expõe o papel do usuário aos templates
            ],
        },
    },
]

# --------------------------------------------------------------------------
# Banco de dados: SQLite por padrão (dev) ou PostgreSQL (recomendado em produção).
# A restrição anti-conflito NO BANCO só existe no PostgreSQL (ver agenda/db_constraints.py).
# --------------------------------------------------------------------------
if os.environ.get("DB_ENGINE", "").lower() in ("postgres", "postgresql"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.environ.get("DB_NAME", "vidaplena"),
            "USER": os.environ.get("DB_USER", "vidaplena"),
            "PASSWORD": os.environ.get("DB_PASSWORD", ""),
            "HOST": os.environ.get("DB_HOST", "localhost"),
            "PORT": os.environ.get("DB_PORT", "5432"),
            "CONN_MAX_AGE": 60,
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

# --------------------------------------------------------------------------
# AUTENTICAÇÃO
# --------------------------------------------------------------------------
# Senhas: Django grava um HASH PBKDF2-SHA256 com salt e muitas iterações (nunca a senha em si).
# Para usar Argon2 (opcional): pip install argon2-cffi e coloque Argon2PasswordHasher primeiro.
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        "OPTIONS": {"min_length": 10},  # mínimo de 10 caracteres
    },
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "agenda:lista"
LOGOUT_REDIRECT_URL = "login"

# Proteção contra força bruta (usada em agenda/views.py -> LoginComLimite)
LOGIN_MAX_TENTATIVAS = 5
LOGIN_BLOQUEIO_SEGUNDOS = 15 * 60

# Cache: em memória no dev. Em produção com vários processos use Redis, para que o contador
# de tentativas de login seja compartilhado entre eles.
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}

# --------------------------------------------------------------------------
# SESSÃO, COOKIES E TRANSPORTE (HTTPS)
# --------------------------------------------------------------------------
HTTPS = _bool("DJANGO_HTTPS", not DEBUG)  # ligado em produção, desligado só no dev local

SESSION_COOKIE_AGE = 60 * 60 * 8          # sessão expira em 8h (turno de trabalho)
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
SESSION_COOKIE_HTTPONLY = True            # JavaScript não lê o cookie de sessão (mitiga XSS)
SESSION_COOKIE_SAMESITE = "Lax"           # reduz CSRF entre sites
CSRF_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_SECURE = HTTPS             # cookie só trafega em HTTPS
CSRF_COOKIE_SECURE = HTTPS
SECURE_SSL_REDIRECT = HTTPS               # http -> https
SECURE_HSTS_SECONDS = 31536000 if HTTPS else 0   # navegador só aceita HTTPS por 1 ano
SECURE_HSTS_INCLUDE_SUBDOMAINS = HTTPS
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "same-origin"
X_FRAME_OPTIONS = "DENY"                  # proíbe embutir o sistema em <iframe> (clickjacking)

if _bool("DJANGO_BEHIND_PROXY"):
    # Quando o Nginx/balanceador termina o TLS e repassa em HTTP interno.
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

# --------------------------------------------------------------------------
# Internacionalização
# --------------------------------------------------------------------------
LANGUAGE_CODE = "pt-br"
TIME_ZONE = "America/Sao_Paulo"
USE_I18N = True
USE_TZ = True  # datas sempre guardadas em UTC e exibidas no fuso acima

# --------------------------------------------------------------------------
# Arquivos estáticos
# --------------------------------------------------------------------------
STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"  # destino do "collectstatic" em produção
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# --------------------------------------------------------------------------
# Logs técnicos (sem dados pessoais: registramos IDs, nunca CPF/nome/senha)
# --------------------------------------------------------------------------
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {"simples": {"format": "%(asctime)s %(levelname)s %(name)s %(message)s"}},
    "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simples"}},
    "root": {"handlers": ["console"], "level": "INFO"},
}
