# Modelo de dados

```mermaid
erDiagram
  USER ||--o| PERFIL : "tem papel"
  UNIDADE ||--o{ PERFIL : "recepção vinculada"
  USER ||--o| PACIENTE : "login opcional"
  USER ||--o| PROFISSIONAL : "login opcional"
  PROFISSIONAL }o--o{ UNIDADE : "atende em"
  PROFISSIONAL ||--o{ HORARIO_ATENDIMENTO : "grade semanal"
  UNIDADE ||--o{ HORARIO_ATENDIMENTO : ""
  PACIENTE ||--o{ AGENDAMENTO : ""
  PROFISSIONAL ||--o{ AGENDAMENTO : ""
  UNIDADE ||--o{ AGENDAMENTO : ""
  USER ||--o{ REGISTRO_AUDITORIA : "autor"
  PERFIL {
    string papel "ADMIN, RECEPCAO, PROFISSIONAL, PACIENTE"
  }
  PACIENTE {
    string cpf UK "11 digitos"
    bool consentimento_lgpd
    datetime consentimento_em
  }
  HORARIO_ATENDIMENTO {
    int dia_semana "0 = segunda"
    time hora_inicio
    time hora_fim
    int duracao_min
  }
  AGENDAMENTO {
    datetime inicio
    datetime fim
    string status "AGENDADO, CONFIRMADO, CONCLUIDO, CANCELADO, FALTOU"
  }
  REGISTRO_AUDITORIA {
    string acao
    string entidade
    string entidade_id
    string detalhe
    string ip
    datetime criado_em
  }
```

## Regras e restrições
| Tabela | Regra |
|---|---|
| `Paciente` | `cpf` único e validado (dígitos verificadores) → evita duplicidade; consentimento LGPD obrigatório no cadastro |
| `HorarioAtendimento` | `hora_fim > hora_inicio`; duração ≥ 5 min |
| `Agendamento` | `CHECK (fim > inicio)`; índices `(profissional, inicio)` e `(status, inicio)`; **PostgreSQL:** exclusão de sobreposição por profissional entre status ativos |
| `Agendamento` | FKs com `PROTECT`: não se apaga paciente/profissional/unidade com histórico |
| `RegistroAuditoria` | Somente inserção (o modelo bloqueia `save` de existentes e `delete`); no admin é somente leitura |
| `Perfil` | Recepção exige unidade |

## Estados do agendamento
`AGENDADO → CONFIRMADO → CONCLUIDO | FALTOU` · `AGENDADO/CONFIRMADO → CANCELADO` (função própria).
`CONCLUIDO`/`FALTOU` só após o horário da consulta. Estados finais não mudam.

## Minimização de dados
Listagens mostram CPF mascarado (`***.456.789-**`); o campo `observacao` é administrativo (proibido registrar dados clínicos);
a auditoria guarda IDs e estados, nunca CPF, nome ou senha.
