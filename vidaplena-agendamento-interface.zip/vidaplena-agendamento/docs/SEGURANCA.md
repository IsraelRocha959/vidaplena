# Segurança: autenticação, autorização e protocolos

> Os controles abaixo estão implementados no código (arquivo indicado entre parênteses). Itens marcados **[produção]** dependem de
> configuração do ambiente de publicação.

## 1. Autenticação (quem é você?)
| Controle | Implementação |
|---|---|
| Armazenamento de senha | Hash **PBKDF2-SHA256** com salt e iterações (padrão Django); a senha nunca é gravada (`settings.py`). Argon2 opcional |
| Política de senha | Mínimo de **10 caracteres**, bloqueia senhas comuns, só numéricas e parecidas com o usuário (`AUTH_PASSWORD_VALIDATORS`) |
| Força bruta | **5 falhas** por (IP + usuário) bloqueiam por **15 min**, mesmo com a senha certa depois; resposta HTTP 429 e auditoria `LOGIN_BLOQUEADO` (`views.LoginComLimite`) |
| Sessão | Cookie `HttpOnly` (JavaScript não lê), `SameSite=Lax`, `Secure` em produção, expira em **8 h** e ao fechar o navegador |
| Logout | Somente por **POST** com token CSRF (`templates/base.html`); evita logout forçado por link malicioso |
| Rastreio | Login, logout e falhas auditados, registrando só o **nome de usuário** tentado, nunca a senha (`signals.py`) |
| Mensagens de erro | Genéricas ("usuário ou senha incorretos"): não revelam se o usuário existe |

**Por que sessão por cookie e não JWT/OAuth?** É uma aplicação web renderizada no servidor: a sessão server-side permite expirar,
revogar e encerrar acessos imediatamente. SSO/OIDC é uma evolução possível (ver `ARQUITETURA.md`).
**Não há MFA no MVP** (recomendado para equipe e administradores).

## 2. Autorização (o que você pode fazer?)
RBAC com 4 papéis + checagem **por objeto**, sempre **no servidor** (`permissions.py`).

| Ação | Admin | Recepção | Profissional | Paciente |
|---|:-:|:-:|:-:|:-:|
| Ver agendamentos | todos | da sua unidade | os seus | os próprios |
| Criar agendamento | ✔ | ✔ (sua unidade) | ✘ | ✔ (para si) |
| Cancelar / reagendar | ✔ | ✔ | ✘ | ✔ (os próprios) |
| Atualizar status | ✔ | ✔ | ✔ (os seus) | ✘ |
| Cadastrar/editar pacientes | ✔ | ✔ | ✘ | ✘ |
| Ver auditoria / painel admin | ✔ | ✘ | ✘ | ✘ |

- **Menor privilégio:** usuário sem perfil, ou recepção sem unidade, não acessa nada.
- **Anti-IDOR:** `get_object_or_404(agendamentos_visiveis(user), pk=...)`: o ID de outra pessoa devolve **404**, sem confirmar que existe.
- Acesso negado por papel gera HTTP 403 e registro `ACESSO_NEGADO` na auditoria.
- Paciente logado agenda **sempre para si**: qualquer CPF enviado é ignorado.

## 3. Protocolos e proteção de transporte
| Camada | Controle | Onde |
|---|---|---|
| TLS/HTTPS | Redirecionamento http→https, cookies `Secure`, **HSTS** de 1 ano | `settings.py` (`HTTPS` ligado por padrão; só desligado com `DJANGO_DEBUG=1`) |
| Certificado/TLS 1.2+ | Terminado no proxy (Nginx/balanceador) **[produção]** | `docs/OPERACAO.md` |
| Proxy | `SECURE_PROXY_SSL_HEADER` com `DJANGO_BEHIND_PROXY=1` | `settings.py` |
| CSRF | Token em todo formulário POST; `CsrfViewMiddleware` | Django + templates |
| Clickjacking | `X-Frame-Options: DENY` e `frame-ancestors 'none'` | `settings.py`, `middleware.py` |
| XSS | Auto-escape dos templates; **CSP** `default-src 'self'` (sem scripts/estilos inline); `nosniff` | `middleware.py` |
| Vazamento por cache | `Cache-Control: no-store` em páginas autenticadas | `middleware.py` |
| Referrer / permissões do navegador | `Referrer-Policy: same-origin`; `Permissions-Policy` desliga câmera, microfone e geolocalização | `settings.py`, `middleware.py` |
| Injeção SQL | Acesso exclusivamente via ORM (consultas parametrizadas); nenhuma SQL montada com entrada do usuário | todo o projeto |
| Segredos | `SECRET_KEY`, senha do banco em variáveis de ambiente/`.env` (fora do Git); falha ao iniciar em produção sem `SECRET_KEY` | `settings.py`, `.gitignore` |

## 4. Mapeamento com OWASP Top 10:2025 (principais)
| Risco | Mitigação no projeto |
|---|---|
| A01 Falha de controle de acesso | RBAC no servidor, filtro por objeto, 404 anti-IDOR, testes de acesso (`tests.py`) |
| Má configuração de segurança | Padrões seguros, `DEBUG` desligado por padrão, cabeçalhos, painel em rota não padrão |
| Falhas de autenticação | Hash forte, política de senha, bloqueio de força bruta, sessão segura |
| Injeção | ORM; validação de formulários; CPF e datas validados |
| Falhas de log e monitoramento | Auditoria imutável + log técnico sem dados pessoais |
| Componentes vulneráveis | Dependências mínimas; manter Django atualizado e rodar `pip list --outdated` periodicamente |

## 5. LGPD (Lei nº 13.709/2018)
- Dados de saúde são **sensíveis**: o sistema aplica medidas técnicas (acima) e administrativas (perfis, auditoria).
- **Consentimento** do titular registrado com data/hora no cadastro. *A base legal adequada para a clínica deve ser definida com apoio jurídico.*
- **Minimização:** CPF mascarado nas listagens; busca de paciente apenas por CPF **completo** ou nome; sem campos clínicos.
- **Rastreabilidade:** quem criou/alterou/cancelou e de qual IP.
- **Pendências para uso real:** política de retenção e descarte, atendimento a pedidos do titular (acesso, correção, eliminação),
  RIPD/relatório de impacto, DPO/encarregado, plano de resposta a incidentes, MFA e criptografia de disco/backup.

## 6. Limitações conhecidas
- Auditoria imutável **na aplicação**; para imutabilidade no banco, adicionar *trigger* ou usuário de banco só com `INSERT`.
- Contador de login em memória (dev); em produção usar Redis.
- IP via `REMOTE_ADDR`: atrás de proxy, configurar o proxy para repassar o IP real e confiar apenas em proxies conhecidos.
- Sem MFA, sem política de expiração de senha, sem scanner automático de dependências.
