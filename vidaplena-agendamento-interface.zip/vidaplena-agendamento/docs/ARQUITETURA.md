# Arquitetura

## Visão geral
Monólito modular em **camadas**, modelo cliente-servidor. Escolha justificada: equipe pequena, uma só implantação, transações simples
entre agenda, pacientes e auditoria. Dá para separar em serviços no futuro sem reescrever as regras (elas vivem em `services.py`).

```mermaid
flowchart LR
  N[Navegador<br/>celular ou PC] -- HTTPS --> P[Proxy reverso<br/>Nginx: TLS]
  P --> A[Gunicorn + Django]
  subgraph Django
    V[views.py / forms.py<br/>apresentação e validação] --> S[services.py<br/>regras de negócio]
    S --> M[models.py<br/>persistência]
    V --> PM[permissions.py<br/>autorização]
  end
  A --- Django
  M --> DB[(PostgreSQL)]
  S --> AU[(RegistroAuditoria)]
```

| Camada | Arquivos | Responsabilidade |
|---|---|---|
| Apresentação | `views.py`, `forms.py`, `templates/`, `static/` | Receber requisições, validar entradas, exibir telas |
| Autorização | `permissions.py`, `middleware.py` | Quem pode ver/fazer o quê; cabeçalhos de segurança |
| Regras de negócio | `services.py` | Conflitos, grade de horários, transições de status, auditoria |
| Persistência | `models.py`, `db_constraints.py` | Entidades, integridade e restrição no banco |

## Tecnologias e por quê
- **Python + Django:** autenticação, sessões, proteção CSRF/XSS/SQL injection e painel admin prontos e amplamente auditados.
- **Renderização no servidor (HTML), sem JavaScript:** menor superfície de ataque, carrega rápido em conexões instáveis, funciona em qualquer aparelho.
- **PostgreSQL:** transações e restrição de exclusão contra sobreposição de horários. **SQLite** apenas para desenvolvimento.
- **Sessão por cookie (e não JWT):** aplicação web com navegador; o servidor controla expiração e logout; cookie `HttpOnly`, `Secure`, `SameSite`.

## Fluxo do agendamento
```mermaid
sequenceDiagram
  participant U as Usuário
  participant V as View (agendamento_novo)
  participant S as services.criar_agendamento
  participant DB as Banco
  U->>V: GET busca (profissional, unidade, data)
  V->>S: horarios_disponiveis()
  S-->>U: slots livres
  U->>V: POST (slot escolhido, CSRF)
  V->>V: valida formulário + permissão (perfil/unidade)
  V->>S: criar_agendamento()
  S->>DB: BEGIN; trava linha do profissional (FOR UPDATE)
  S->>DB: existe sobreposição? (profissional e paciente)
  alt livre
    S->>DB: INSERT agendamento + INSERT auditoria; COMMIT
    S-->>U: sucesso
  else conflito (ou restrição do PostgreSQL recusa)
    S-->>U: "Este horário acabou de ser ocupado"
  end
```

### Anti-conflito em duas camadas
1. **Aplicação:** transação + `SELECT ... FOR UPDATE` no profissional serializa tentativas simultâneas; consulta de sobreposição
   (`inicioA < fimB E fimA > inicioB`) entre agendamentos ativos (agendado/confirmado).
2. **Banco (PostgreSQL):** `EXCLUDE USING gist (profissional_id WITH =, tstzrange(inicio, fim) WITH &&) WHERE status IN (...)`.
   Se duas gravações colidirem mesmo assim, o banco recusa e o sistema converte em mensagem amigável.
Cancelado, concluído e faltou **liberam** o horário.

## Integrações
O MVP **não depende de serviços externos**. Integrações existentes e pontos de extensão:

| Integração | Situação | Observação |
|---|---|---|
| Banco de dados | SQLite (dev) / PostgreSQL (prod) | Configurado por variáveis de ambiente (`DB_*`) |
| Cache | Memória local (dev) | Em produção usar **Redis** para o contador de login (compartilhado entre processos) |
| Painel admin Django | Ativo em `/gestao-admin/` | Cadastros de unidades, profissionais, horários, perfis |
| E-mail / WhatsApp / SMS | **Não implementado** | Ponto de extensão: chamar um *adaptador* de notificação ao final de `criar_agendamento`/`reagendar`/`cancelar` (em tarefa assíncrona, p. ex. Celery) |
| Autenticação externa (SSO/OIDC) | **Não implementado** | Possível via biblioteca compatível com Django, mantendo `Perfil` como fonte do papel |
| Painel de indicadores | **Não implementado** | Consultas agregadas sobre `Agendamento` (faltas, ocupação, tempo médio) |

## Tratamento de erros
- Regras de negócio levantam `RegraNegocioError`/`ConflitoHorarioError` com mensagem segura → exibida ao usuário.
- Entradas inválidas: formulários exibem erro por campo.
- Permissão: HTTP 403 (`403.html`); recurso fora do escopo do usuário: HTTP 404 (`404.html`).
- Erro inesperado: `500.html` genérico (sem detalhes técnicos); detalhes vão ao log do servidor, **sem dados pessoais**.
- Falha na auditoria não derruba a operação principal, mas é registrada no log técnico.

## Evolução sugerida
Lembretes automáticos (reduzem faltas) → painel de indicadores → MFA para equipe → PWA/modo offline parcial → integração com mensageria.
