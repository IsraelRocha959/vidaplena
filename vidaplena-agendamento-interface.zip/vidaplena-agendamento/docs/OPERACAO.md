# Testes, versionamento, publicação e manutenção

## Testes
`python manage.py test`. Cobertura: regra de conflito (profissional e paciente), grade de horários, passado, cancelamento/reagendamento,
transições de status, CPF, imutabilidade da auditoria, permissões por perfil (inclusive IDOR entre pacientes e unidades),
CSRF, método HTTP, fluxo web de agendamento e bloqueio de força bruta.
**Pendente:** testes de carga e testes da restrição de exclusão rodando contra PostgreSQL (CI com serviço `postgres`).

## Versionamento (Git)
```bash
git init && git add . && git commit -m "MVP de agendamento"
```
Fluxo sugerido: `main` protegida; ramificações `feature/...`; *pull request* com revisão e testes passando antes de integrar;
mensagens de commit claras; **nunca** versionar `.env`, `db.sqlite3` ou backups (já no `.gitignore`).

## Publicação (esboço)
1. Servidor Linux com Python, PostgreSQL e Nginx. `pip install -r requirements-prod.txt`.
2. `.env` de produção: `DJANGO_DEBUG=0`, `DJANGO_SECRET_KEY` forte, `DJANGO_ALLOWED_HOSTS`, `DJANGO_CSRF_TRUSTED_ORIGINS`, `DJANGO_BEHIND_PROXY=1`, `DB_*`.
3. `python manage.py migrate` e `python manage.py collectstatic --noinput`.
4. Gunicorn: `gunicorn vidaplena.wsgi:application --bind 127.0.0.1:8000 --workers 3` (gerenciado por *systemd*).
5. Nginx com certificado TLS (ex.: Let's Encrypt), redirecionando 80→443, repassando `X-Forwarded-Proto` e servindo `/static/` a partir de `staticfiles/`.
6. Checagem: `python manage.py check --deploy` (deve ficar sem avisos relevantes).
7. Cache **Redis** (trocar `CACHES`) quando houver mais de um processo.
Primeiro ambiente: **homologação**, validar com a recepção; depois produção.

## Backup e recuperação
```bash
# diário (cron) – exemplo
pg_dump -Fc -h localhost -U vidaplena vidaplena > backups/vidaplena_$(date +%F).dump
# restauração
pg_restore -c -d vidaplena backups/vidaplena_AAAA-MM-DD.dump
```
Guardar cópias **criptografadas** fora do servidor, reter por prazo definido e **testar a restauração** periodicamente.

## Monitoramento e manutenção
- Logs do Gunicorn/Django (sem dados pessoais) e alerta de erros 5xx; acompanhar na tela **Auditoria** os `LOGIN_FALHOU`, `LOGIN_BLOQUEADO` e `ACESSO_NEGADO`.
- Corretiva: corrigir falhas e publicar via fluxo de PR. Evolutiva: priorizar lembretes automáticos e indicadores.
- Atualizar Django (versões LTS/segurança) e dependências regularmente; rodar os testes após cada atualização.
- Rotacionar `SECRET_KEY` e senhas do banco em caso de suspeita de vazamento.
