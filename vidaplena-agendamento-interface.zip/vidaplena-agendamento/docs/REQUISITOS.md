# Requisitos e escopo do MVP

## Contexto e problema
Quatro unidades agendam por telefone, mensagens, planilhas e papel, sem sincronização: duplicidade de pacientes, horários conflitantes,
falta de confirmação, ausência de indicadores e riscos de segurança (dados em grupos de mensagens, senhas repetidas, planilhas sem controle de acesso).

## Usuários (perfis)
| Perfil | Necessidade principal | Acesso no sistema |
|---|---|---|
| Paciente | Agendar, reagendar e cancelar sem repetir dados | Apenas os **próprios** agendamentos |
| Recepção | Agendar para pacientes, cadastrar pacientes, reorganizar agenda | Agendamentos da **sua unidade**; cadastro de pacientes |
| Profissional | Ver a própria agenda e registrar confirmação/conclusão/falta | Apenas os **seus** atendimentos; atualizar status |
| Administrador (direção/TI) | Cadastros, perfis e auditoria | Tudo, inclusive painel `/gestao-admin/` e trilha de auditoria |

## Requisitos funcionais (MVP)
| ID | Requisito | Onde está |
|---|---|---|
| RF01 | Autenticação por usuário e senha | `LoginComLimite`, `settings.py` |
| RF02 | Autorização por perfis | `permissions.py` |
| RF03 | Cadastro de pacientes (CPF validado, consentimento LGPD) | `PacienteForm`, `paciente_form` |
| RF04 | Cadastro de profissionais, unidades e grade de horários | `admin.py` |
| RF05 | Consulta de disponibilidade | `services.horarios_disponiveis` |
| RF06 | Agendamento sem conflito de horário | `services.criar_agendamento` + restrição PostgreSQL |
| RF07 | Cancelamento (libera o horário) | `services.cancelar_agendamento` |
| RF08 | Reagendamento | `services.reagendar_agendamento` |
| RF09 | Atualização de status (agendado, confirmado, concluído, faltou, cancelado) | `services.atualizar_status` |
| RF10 | Registro de operações relevantes (auditoria) | `RegistroAuditoria`, `signals.py` |

## Requisitos não funcionais
| ID | Requisito | Como é atendido |
|---|---|---|
| RNF01 | Segurança e proteção de dados (LGPD) | Ver `SEGURANCA.md` |
| RNF02 | Responsividade (celular e computador) | CSS fluido, sem frameworks |
| RNF03 | Acessibilidade (WCAG 2.2) | Contraste, foco visível, rótulos, navegação por teclado, "pular para o conteúdo" |
| RNF04 | Desempenho em conexões instáveis | Páginas leves, sem JavaScript nem bibliotecas externas |
| RNF05 | Integridade dos dados | Transações, chaves estrangeiras, restrições no banco |
| RNF06 | Rastreabilidade | Auditoria imutável |
| RNF07 | Manutenibilidade | Camadas separadas, testes automatizados, documentação |

## Fora do MVP (evolução)
Notificações automáticas (lembretes), prontuário eletrônico, pagamentos, painel de indicadores (faltas, ocupação, tempo médio),
autoatendimento de cadastro, MFA, aplicativo instalável (PWA).
