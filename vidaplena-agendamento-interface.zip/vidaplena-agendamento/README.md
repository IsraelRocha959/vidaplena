# Vida Plena – Aplicação de Agendamento (MVP)

Aplicação web responsiva para centralizar os agendamentos da Clínica Popular Vida Plena (4 unidades).
Desenvolvida com **Python 3.10+ e Django 5.2**. Banco: **SQLite** (desenvolvimento) ou **PostgreSQL** (produção).

> ⚠️ Projeto acadêmico (disciplina *Imersão Profissional: Implementação de uma Aplicação*). Antes de uso real com dados
> de pacientes, exige revisão de segurança, jurídica (LGPD) e testes de carga.

## O que o MVP faz
Login · perfis (Administrador, Recepção, Profissional, Paciente) · cadastro de pacientes · cadastro de unidades,
profissionais e grade de horários (painel admin) · consulta de disponibilidade · agendamento · cancelamento ·
reagendamento · atualização de status · bloqueio de conflitos de horário · trilha de auditoria · interface responsiva e acessível.

## Como rodar no VS Code (passo a passo)

**Pré-requisitos:** Python 3.10 ou superior ([python.org](https://www.python.org/downloads/); no Windows marque *Add Python to PATH*), VS Code e a extensão **Python** (Microsoft).

1. Descompacte o projeto e abra a pasta no VS Code (*File → Open Folder*).
2. Abra o terminal integrado (`Ctrl+'`) e crie o ambiente virtual:
   ```bash
   python -m venv .venv
   ```
3. Ative o ambiente:
   - Windows (PowerShell): `.venv\Scripts\Activate.ps1`  *(se bloquear: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`)*
   - Windows (cmd): `.venv\Scripts\activate.bat`
   - macOS/Linux: `source .venv/bin/activate`
4. Instale as dependências: `pip install -r requirements.txt`
5. Crie o arquivo de configuração: copie `.env.example` para `.env` (Windows: `copy .env.example .env`).
6. Crie as tabelas **(os dois comandos, nesta ordem)**:
   ```bash
   python manage.py makemigrations agenda
   python manage.py migrate
   ```
7. Dados de demonstração (gera usuários e **imprime a senha uma única vez**): `python manage.py seed_demo`
8. Crie o administrador: `python manage.py createsuperuser`
9. Rode: `python manage.py runserver` e acesse **http://127.0.0.1:8000/**
10. Painel de cadastros (unidades, profissionais, horários, usuários/perfis): **http://127.0.0.1:8000/gestao-admin/**
11. Testes automatizados: `python manage.py test`

No VS Code, selecione o interpretador (`Ctrl+Shift+P` → *Python: Select Interpreter* → `.venv`). Para depurar, use *Run and Debug → Django: runserver*.

### Roteiro rápido para testar
1. Entre em `/gestao-admin/` como administrador e confira a unidade, o profissional e a grade criados pelo `seed_demo`.
2. Entre em `/entrar/` como `recepcao.centro`, vá em **Novo agendamento**, escolha *Dra. Ana Souza*, unidade *Centro* e um **dia útil futuro**, escolha um horário e informe o CPF `529.982.247-25`.
3. Tente agendar o mesmo horário de novo (ou abra duas abas): o sistema recusa o conflito.
4. Entre como `paciente.demo`: só aparecem os agendamentos dele. Tente abrir o ID de outro agendamento na URL: retorna 404.
5. Como administrador, abra **Auditoria** para ver logins, agendamentos, cancelamentos e acessos negados.

### Usar PostgreSQL (recomendado para testar a restrição anti-conflito do banco)
1. `docker compose up -d` (ou instale o PostgreSQL) e `pip install -r requirements-prod.txt`.
2. No `.env`: `DB_ENGINE=postgres`, `DB_PASSWORD=...` (e demais `DB_*`).
3. Repita `makemigrations`, `migrate`. Ao final do `migrate`, a restrição de exclusão é criada automaticamente.

## Estrutura
```
manage.py · requirements*.txt · .env.example · docker-compose.yml
vidaplena/        configuração (settings.py = segurança), rotas
agenda/
  models.py       entidades e validadores (CPF)
  services.py     REGRAS DE NEGÓCIO (conflito, cancelar, reagendar, status, auditoria)
  permissions.py  autorização por perfil e por objeto
  views.py        telas + login com limite de tentativas
  forms.py        validação de entradas
  db_constraints.py  restrição de exclusão (PostgreSQL)
  middleware.py   cabeçalhos de segurança (CSP etc.)   signals.py  auditoria de login
  admin.py        painel administrativo               tests.py    testes automatizados
templates/ static/   interface (HTML/CSS leves, sem JavaScript)
docs/             documentação técnica
```

## Documentação
- [docs/REQUISITOS.md](docs/REQUISITOS.md) – usuários, requisitos funcionais/não funcionais e escopo do MVP
- [docs/ARQUITETURA.md](docs/ARQUITETURA.md) – camadas, fluxo do agendamento, integrações, decisões
- [docs/MODELO_DE_DADOS.md](docs/MODELO_DE_DADOS.md) – diagrama ER e dicionário
- [docs/SEGURANCA.md](docs/SEGURANCA.md) – autenticação, autorização, protocolos e controles (OWASP/LGPD)
- [docs/OPERACAO.md](docs/OPERACAO.md) – testes, versionamento, publicação, backup e manutenção

## Limitações conhecidas
Sem notificações automáticas (e-mail/WhatsApp), sem prontuário, sem autoatendimento de cadastro de paciente, sem testes de carga,
sem MFA. Veja a seção de evolução em `docs/ARQUITETURA.md`.
